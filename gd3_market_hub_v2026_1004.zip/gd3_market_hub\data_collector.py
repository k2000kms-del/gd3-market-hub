# -*- coding: utf-8 -*-
"""
GD 3.0 Market Hub - 데이터 수집기 (GitHub Actions 전용)
- 한국 주식시장 개장 시간(09:00~15:30 KST)에 GitHub Actions로 자동 실행
- KIS API + FinanceDataReader로 시장 데이터 수집
- 수집된 CSV를 레포지토리 data/ 폴더에 저장 (GitHub Actions가 자동 커밋)
- 모든 민감 정보는 환경변수(GitHub Secrets)에서 읽음
"""

import os
import sys

# ── 윈도우 환경 이모지 출력 시 cp949 디코딩 에러 방지 ───────────────
try:
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
    if sys.stderr.encoding != 'utf-8':
        sys.stderr.reconfigure(encoding='utf-8')
except AttributeError:
    pass

import json
import requests
import pandas as pd
import numpy as np
import time
import FinanceDataReader as fdr
from datetime import datetime, timedelta, timezone

# ── 한국 표준시(KST) 강제 타임존 정의 (GitHub Actions 미국/UTC 서버 시간 오차 원천 차단) ──
KST = timezone(timedelta(hours=9))

# ── TA-Lib 임포트 및 예외 처리 (하이브리드 구조) ─────────────────
HAS_TALIB = False
try:
    import talib
    HAS_TALIB = True
except ImportError:
    print("  ⚠️ TA-Lib 임포트 실패 - 순수 파이썬(pandas) 폴백 엔진으로 대체 동작합니다.")

# ── KIS API 설정 (환경변수에서 읽기) ────────────────────────────
# KIS API 인증 키 탐색 (대체 별칭 KIS_KEY / KIS_SECRET 지원)
APP_KEY    = os.environ.get('KIS_APP_KEY', os.environ.get('KIS_KEY', ''))
APP_SECRET = os.environ.get('KIS_APP_SECRET', os.environ.get('KIS_SECRET', ''))
URL_BASE   = 'https://openapi.koreainvestment.com:9443'

# ── Supabase 설정 (환경변수에서 읽기) ───────────────────────────
SUPABASE_URL = os.environ.get('SUPABASE_URL', '')
SUPABASE_ANON_KEY = os.environ.get('SUPABASE_ANON_KEY', '')
supabase = None
if SUPABASE_URL and SUPABASE_ANON_KEY:
    try:
        from supabase import create_client
        supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)
        print("  ✅ Supabase client initialized successfully")
    except Exception as e:
        print(f"  ⚠️ Supabase initialization failed: {e}")

# ── 로컬 저장 경로 (레포지토리 data/ 폴더) ──────────────────────
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')


# ── KIS API 헬퍼 ────────────────────────────────────────────────
def get_access_token():
    """KIS API 액세스 토큰 발급"""
    res = requests.post(
        f'{URL_BASE}/oauth2/tokenP',
        headers={'content-type': 'application/json'},
        data=json.dumps({
            'grant_type': 'client_credentials',
            'appkey': APP_KEY,
            'appsecret': APP_SECRET
        })
    )
    return res.json().get('access_token')


def is_market_open():
    """한국 주식시장 개장 여부 확인 (09:00~15:30 평일 KST 기준)"""
    now = datetime.now(KST)
    if now.weekday() >= 5:  # 토/일
        return False
    h, m = now.hour, now.minute
    return (9, 0) <= (h, m) <= (15, 30)


def fetch_stock_supply(token, stock_code):
    """KIS API: 종목별 외국인/기관 순매수 조회"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'authorization': f'Bearer {token}',
            'appkey': APP_KEY,
            'appsecret': APP_SECRET,
            'tr_id': 'FHKST01010900',
            'custtype': 'P',
        }
        params = {
            'FID_COND_MRKT_DIV_CODE': 'J',
            'FID_INPUT_ISCD': stock_code,
        }
        res = requests.get(
            f'{URL_BASE}/uapi/domestic-stock/v1/quotations/inquire-investor',
            headers=headers, params=params
        )
        res_json = res.json()
        output = res_json.get('output', [])

        def _safe_int(val):
            try:
                if val is None:
                    return 0
                val_str = str(val).strip()
                if not val_str or val_str == 'None':
                    return 0
                return int(val_str)
            except Exception:
                return 0

        # [수정] 장중에는 당일(output[0]) 수급이 빈 문자열로 반환됨 (KRX 잠정치 미집계)
        # frgn_ntby_qty 또는 orgn_ntby_qty에 실제 값이 있는 최근 영업일 항목을 순서대로 탐색
        target_data = {}
        if isinstance(output, list):
            for row in output:
                frgn_val = str(row.get('frgn_ntby_qty', '')).strip()
                orgn_val = str(row.get('orgn_ntby_qty', '')).strip()
                if frgn_val or orgn_val:
                    target_data = row
                    break
        elif isinstance(output, dict):
            target_data = output

        return {
            'Foreign_Net':       _safe_int(target_data.get('frgn_ntby_qty', 0)),
            'Institutional_Net': _safe_int(target_data.get('orgn_ntby_qty', 0)),
            'Program_Net':       _safe_int(target_data.get('pgtr_ntby_qty', 0)),
        }
    except Exception as e:
        print(f"  ⚠️ fetch_stock_supply({stock_code}) 실패: {e}")
        return {'Foreign_Net': 0, 'Institutional_Net': 0, 'Program_Net': 0}


def fetch_stock_sector(token, stock_code):
    """KIS API: 종목의 HTS 업종명 조회 (bstp_kor_isnm)"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'authorization': f'Bearer {token}',
            'appkey': APP_KEY,
            'appsecret': APP_SECRET,
            'tr_id': 'FHKST01010100',
        }
        params = {
            'FID_COND_MRKT_DIV_CODE': 'J',
            'FID_INPUT_ISCD': stock_code,
        }
        res = requests.get(
            f'{URL_BASE}/uapi/domestic-stock/v1/quotations/inquire-price',
            headers=headers, params=params
        )
        data = res.json().get('output', {})
        return data.get('bstp_kor_isnm', '').strip()
    except Exception:
        return ''


def fetch_market_index(token, market_code='0001'):
    """KIS API: 코스피/코스닥 지수 조회"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'authorization': f'Bearer {token}',
            'appkey': APP_KEY,
            'appsecret': APP_SECRET,
            'tr_id': 'FHPUP02100000',
        }
        params = {
            'FID_COND_MRKT_DIV_CODE': 'U',
            'FID_INPUT_ISCD': market_code,
        }
        res = requests.get(
            f'{URL_BASE}/uapi/domestic-stock/v1/quotations/inquire-index-price',
            headers=headers, params=params
        )
        return res.json().get('output', {})
    except Exception:
        return {}


def fetch_market_investor(token, market_div='J'):
    """KIS API: 시장별 투자자 순매수 조회 (억원 단위)"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'authorization': f'Bearer {token}',
            'appkey': APP_KEY,
            'appsecret': APP_SECRET,
            'tr_id': 'FHPTJ04400000',
        }
        now_k = datetime.now(KST)
        params = {
            'FID_COND_MRKT_DIV_CODE': market_div,
            'FID_INPUT_DATE_1': (now_k - timedelta(days=max(0, now_k.weekday() - 4))).strftime('%Y%m%d'),
        }
        res = requests.get(
            f'{URL_BASE}/uapi/domestic-stock/v1/quotations/inquire-investor',
            headers=headers, params=params
        )
        return res.json().get('output', [])
    except Exception:
        return []


# ── 로컬 CSV 저장 ────────────────────────────────────────────────
def save_df_to_local(df, filename):
    """DataFrame을 data/ 및 streamlit_app/data/ 폴더에 동시 저장 (클라우드/로컬 일치화)"""
    base_proj_dir = os.path.dirname(os.path.abspath(__file__))
    dirs_to_save = [
        DATA_DIR,
        os.path.join(base_proj_dir, 'streamlit_app', 'data')
    ]
    for d in dirs_to_save:
        try:
            os.makedirs(d, exist_ok=True)
            filepath = os.path.join(d, filename)
            df.to_csv(filepath, index=False, encoding='utf-8-sig')
        except Exception as e:
            print(f"  ⚠️ {filename} 저장 실패 in {d}: {e}")
    print(f'  ✅ {filename} → data/ 및 streamlit_app/data/ 동시 저장 완료 ({len(df)}행)')


# ── 데이터 수집 함수들 ───────────────────────────────────────────
def collect_full_market():
    """FinanceDataReader: 전체 시장 데이터 수집 (실패 시 네이버 금융 크롤링으로 폴백)"""
    print('📊 전체 시장 데이터 수집 중...')
    df_all = pd.DataFrame()
    use_naver_fallback = False
    
    try:
        df_ks = fdr.StockListing('KOSPI')
        df_kq = fdr.StockListing('KOSDAQ')
        df_all = pd.concat([df_ks, df_kq], ignore_index=True)
        if df_all.empty:
            use_naver_fallback = True
    except Exception as e:
        print(f'  ⚠️ FinanceDataReader 수집 실패: {e}. 네이버 금융 크롤링 폴백을 시도합니다.')
        use_naver_fallback = True

    if use_naver_fallback:
        try:
            import re
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            all_dfs = []
            
            for sosok, market_name in [(0, 'KOSPI'), (1, 'KOSDAQ')]:
                page = 1
                while True:
                    url = f"https://finance.naver.com/sise/sise_market_sum.naver?sosok={sosok}&page={page}"
                    res = requests.get(url, headers=headers, timeout=10)
                    if res.status_code != 200:
                        break
                    res.encoding = 'euc-kr'
                    
                    # tr onMouseOver가 포함된 행들만 추출 (대소문자 무시)
                    tr_blocks = re.findall(r'<tr\s+onMouseOver="mouseOver\(this\)"[^>]*>(.*?)</tr>', res.text, re.DOTALL | re.IGNORECASE)
                    if not tr_blocks:
                        break
                    
                    page_rows = []
                    for tr in tr_blocks:
                        code_match = re.search(r'code=([0-9]{6})', tr)
                        if not code_match:
                            continue
                        code = code_match.group(1)
                        
                        tds = re.findall(r'<td[^>]*>(.*?)</td>', tr, re.DOTALL)
                        td_texts = [re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', td)).strip() for td in tds]
                        
                        if len(td_texts) < 10:
                            continue
                            
                        name = td_texts[1]
                        
                        close_val = pd.to_numeric(td_texts[2].replace(',', ''), errors='coerce')
                        close_val = 0.0 if pd.isna(close_val) else float(close_val)
                        
                        ratio_val = 0.0
                        ratio_str = td_texts[4].replace('%', '').replace('+', '').strip()
                        try:
                            ratio_val = float(ratio_str)
                        except:
                            pass
                            
                        changes_txt = td_texts[3]
                        changes_val = 0
                        nums = re.findall(r'\d+', changes_txt.replace(',', ''))
                        if nums:
                            try:
                                changes_val = int(nums[0])
                                if ratio_val < 0:
                                    changes_val = -changes_val
                            except:
                                pass
                                
                        marcap_val = pd.to_numeric(td_texts[6].replace(',', ''), errors='coerce')
                        marcap_val = 0.0 if pd.isna(marcap_val) else float(marcap_val) * 100_000_000
                        
                        stocks_val = pd.to_numeric(td_texts[7].replace(',', ''), errors='coerce')
                        stocks_val = 0.0 if pd.isna(stocks_val) else float(stocks_val) * 1000
                        
                        volume_val = pd.to_numeric(td_texts[9].replace(',', ''), errors='coerce')
                        volume_val = 0.0 if pd.isna(volume_val) else float(volume_val)
                        
                        page_rows.append({
                            'Symbol': code,
                            'ISU_CD': "",
                            'Name': name,
                            'Market': market_name,
                            'Dept': "",
                            'Close': close_val,
                            'ChangeCode': '1' if ratio_val > 0 else ('2' if ratio_val < 0 else '3'),
                            'Changes': changes_val,
                            'ChagesRatio': ratio_val,
                            'Open': close_val,
                            'High': close_val,
                            'Low': close_val,
                            'Volume': volume_val,
                            'Amount': close_val * volume_val,
                            'Marcap': marcap_val,
                            'Stocks': stocks_val,
                            'MarketId': 'STK' if market_name == 'KOSPI' else 'KSQ'
                        })
                    
                    if not page_rows:
                        break
                        
                    target_df = pd.DataFrame(page_rows)
                    cols = ['Symbol', 'ISU_CD', 'Name', 'Market', 'Dept', 'Close', 'ChangeCode', 'Changes', 'ChagesRatio', 'Open', 'High', 'Low', 'Volume', 'Amount', 'Marcap', 'Stocks', 'MarketId']
                    
                    filtered_page_df = target_df[target_df['Marcap'] >= 50_000_000_000]
                    if not filtered_page_df.empty:
                        all_dfs.append(filtered_page_df[cols])
                    
                    min_marcap_in_page = target_df['Marcap'].min() / 100_000_000
                    print(f"  [Naver Fallback] {market_name} Page {page} loaded. Min Marcap: {min_marcap_in_page:.1f}억원. Kept {len(filtered_page_df)} items.")
                    
                    if min_marcap_in_page < 500:
                        break
                        
                    page += 1
                    time.sleep(0.2)
            
            if all_dfs:
                df_all = pd.concat(all_dfs, ignore_index=True)
                print(f"  ✅ 네이버 금융 크롤링 폴백 완료: {len(df_all)}개 종목 수집됨.")
            else:
                print("  ❌ 네이버 금융 크롤링 폴백 실패: 수집된 데이터 없음.")
        except Exception as ex:
            print(f"  ❌ 네이버 금융 크롤링 폴백 중 예외 발생: {ex}")

    # ── [종목 필터링] 부실/특수 종목 제외 ──
    if not df_all.empty:
        if 'Name' in df_all.columns:
            junk_patterns = '스팩|SPAC|ETN|ETF|제[0-9]+호|우$|우[A-Z]$|리츠|인프라'
            df_all = df_all[~df_all['Name'].str.contains(junk_patterns, regex=True, na=False)]
        
        if 'Volume' in df_all.columns:
            df_all = df_all[df_all['Volume'] > 0]

        if 'Marcap' in df_all.columns:
            df_all = df_all[pd.to_numeric(df_all['Marcap'], errors='coerce').fillna(0) >= 50_000_000_000]

        df_all = df_all.reset_index(drop=True)

        # 컬럼 정리
        col_map = {
            'Symbol': 'Code', 'Name': 'Name', 'Market': 'Market',
            'Close': 'Close', 'ChagesRatio': 'ChagesRatio',
            'Volume': 'Volume', 'Amount': 'Amount', 'Marcap': 'Marcap'
        }
        df_all = df_all.rename(columns={k: v for k, v in col_map.items() if k in df_all.columns})
        for col in ['Close', 'ChagesRatio', 'Volume', 'Amount', 'Marcap']:
            if col in df_all.columns:
                df_all[col] = pd.to_numeric(df_all[col], errors='coerce').fillna(0)

        print(f'  → {len(df_all)}개 종목 최종 정제 완료')
        return df_all
    else:
        return pd.DataFrame()


def collect_high_density(token, df_full):
    """KIS API: 수급 상위 종목 데이터 수집

    [목적] 선행 매수 타이밍 포착을 위한 후보군 확대 전략:
    - Pool A: 거래대금 절대 상위 50개 (시장 주도 종목)
    - Pool B: 시가총액 대비 거래대금 회전율 상위 20개 (아직 주목받지 않은 선행 이동 종목)
    두 풀을 합산(중복 제거)하여 최대 70개 종목을 수급 분석 대상으로 삼음.
    """
    print('📡 수급 상위 종목 데이터 수집 중...')
    if df_full.empty:
        return pd.DataFrame()

    # ── Pool A: 거래대금 절대 상위 50개 (시장 주도·핫 종목) ──
    pool_a = df_full.nlargest(50, 'Amount') if 'Amount' in df_full.columns else df_full.head(50)

    # ── Pool B: 시가총액 대비 거래대금 회전율 상위 20개 (선행 포착) ──
    # 아직 거래대금 절대규모는 크지 않지만 시총 대비 거래가 활발해지는 종목을 조기에 포착
    pool_b = pd.DataFrame()
    try:
        df_remaining = df_full[~df_full.index.isin(pool_a.index)].copy()
        if 'Marcap' in df_remaining.columns and 'Amount' in df_remaining.columns:
            df_remaining['Marcap_num'] = pd.to_numeric(df_remaining['Marcap'], errors='coerce').fillna(0)
            df_remaining['Amount_num'] = pd.to_numeric(df_remaining['Amount'], errors='coerce').fillna(0)
            # 최소 거래대금 10억 이상이고 시총이 있는 종목만 대상
            df_remaining = df_remaining[
                (df_remaining['Marcap_num'] > 0) & (df_remaining['Amount_num'] >= 1_000_000_000)
            ]
            df_remaining['TurnoverRatio'] = df_remaining['Amount_num'] / df_remaining['Marcap_num']
            pool_b = df_remaining.nlargest(20, 'TurnoverRatio')
    except Exception as e:
        print(f'  ⚠️ Pool B 선행 포착 조회 실패: {e}')

    # ── Pool C: 사용자 보유 포트폴리오 종목 (상시 필수 수급 감시군) ──
    pool_c = pd.DataFrame()
    try:
        port_file = os.path.join(DATA_DIR, 'my_portfolio.json')
        if os.path.exists(port_file):
            with open(port_file, 'r', encoding='utf-8') as pf:
                port_dict = json.load(pf)
            port_codes = [str(c).zfill(6) for c in port_dict.keys()]
            if 'Code' in df_full.columns:
                pool_c = df_full[df_full['Code'].astype(str).str.zfill(6).isin(port_codes)].copy()
                print(f'  → Pool C (보유 포트폴리오): {len(pool_c)}개 종목 상시 포함')
    except Exception as e:
        print(f'  ⚠️ Pool C (포트폴리오) 로드 실패: {e}')

    # ── 세 풀 합산 및 중복 제거 ──
    top_stocks = pd.concat([pool_a, pool_b, pool_c]).drop_duplicates(subset=['Code']).reset_index(drop=True)
    print(f'  → Pool A: {len(pool_a)}개, Pool B: {len(pool_b)}개, Pool C(포트폴리오): {len(pool_c)}개, 최종 합산: {len(top_stocks)}개 종목 대상')

    rows = []
    for _, row in top_stocks.iterrows():
        code = str(row.get('Code', '')).zfill(6)
        supply = fetch_stock_supply(token, code)

        rows.append({
            'Code': code,
            'Name': row.get('Name', ''),
            'Market': row.get('Market', ''),
            'Close': row.get('Close', 0),
            'ChagesRatio': row.get('ChagesRatio', 0),
            'Volume': row.get('Volume', 0),
            'Amount': row.get('Amount', 0),
            'Marcap': row.get('Marcap', 0),
            'Foreign_Net':        supply['Foreign_Net'],
            'Institutional_Net':  supply['Institutional_Net'],
            'Program_Net':        supply['Program_Net'],
            'Total_Combined_Net': supply['Foreign_Net'] + supply['Institutional_Net'],
            'FDR_Sector':         row.get('Sector', ''),
            'FDR_Industry':       row.get('Industry', ''),
        })

    df = pd.DataFrame(rows)
    print(f'  → {len(df)}개 종목 수급 수집 완료')
    return df


# ── 섹터 분류 함수 ────────────────────────────────────────────────
def _classify_sector(code, name, fdr_sector="", fdr_industry=""):
    """종목 코드/이름/FDR 분류 기반 섹터 분류
    반환값: 섹터 문자열 (반도체, 자동차, 금융, 에너지, 항공운송, 바이오, 통신, 내수, 건설, 기타 공식 업종명)
    """
    # 주요 종목 코드 직접 매핑 (정확도 최우선)
    sector_by_code = {
        # 반도체
        '005930': '반도체', '000660': '반도체', '042700': '반도체',
        '240810': '반도체', '403870': '반도체', '090360': '반도체',
        '005290': '반도체', '357780': '반도체', '054730': '반도체',
        '104830': '반도체', '000990': '반도체', '336370': '반도체',
        # 자동차
        '005380': '자동차', '000270': '자동차', '012330': '자동차',
        '011210': '자동차', '161390': '자동차', '204320': '자동차',
        # 금융
        '055550': '금융', '105560': '금융', '086790': '금융',
        '316140': '금융', '032830': '금융', '000810': '금융',
        '138930': '금융', '139130': '금융',
        # 에너지/정유
        '096770': '에너지', '010950': '에너지', '078930': '에너지',
        '267250': '에너지',
        # 항공/운송
        '003490': '항공운송', '020560': '항공운송', '011200': '항공운송',
        '000120': '항공운송',
        # 바이오
        '207940': '바이오', '068270': '바이오', '000100': '바이오',
        '128940': '바이오', '326030': '바이오',
        # 통신
        '017670': '통신', '030200': '통신', '032640': '통신',
        # 건설
        '028260': '건설', '000720': '건설', '375500': '건설',
        '010140': '건설',
    }
    if code in sector_by_code:
        return sector_by_code[code]

    # 이름 및 FDR 분류 정보를 모두 고려한 통합 검색 텍스트 생성
    check_str = f"{fdr_sector} {fdr_industry} {name}".lower()

    if any(kw in check_str for kw in ['반도체', 'semiconductor', '웨이퍼', '파운드리', '식각', 'hbm', 'dram', 'nand', 'ic', '칩']):
        return '반도체'
    if any(kw in check_str for kw in ['자동차', '모터스', '모비스', '타이어', '부품', '완성차', 'automotive']):
        return '자동차'
    if any(kw in check_str for kw in ['금융', '은행', '증권', '보험', '캐피탈', '카드', '지주회사', 'financial', 'bank']):
        if '금융' in check_str or '은행' in check_str or '카드' in check_str or '투자' in check_str:
            return '금융'
    if any(kw in check_str for kw in ['에너지', '정유', '오일', '가스', '석유', '석탄', '발전', '전력', 'energy', 'oil']):
        return '에너지'
    if any(kw in check_str for kw in ['항공', '에어', '해운', '물류', '운송', '택배', 'shipping', 'transport']):
        return '항공운송'
    if any(kw in check_str for kw in ['바이오', '제약', '의약', '셀', '헬스', '테라퓨틱', '의료기기', 'bio', 'pharma']):
        return '바이오'
    if any(kw in check_str for kw in ['텔레콤', 'telecom', '통신']):
        return '통신'
    if any(kw in check_str for kw in ['건설', '물산', '이앤씨', '산업개발', '건축', '토목', 'construction']):
        return '건설'
    if any(kw in check_str for kw in ['식품', '유통', '마트', '백화점', '패션', '의류', '화장품', '소매', '식음료', 'cosmetic', 'retail']):
        return '내수'

    # 매크로 가중치 적용 9대 섹터에 속하지 않는 경우, '기타'로 뭉뚱그리지 않고 FDR 제공 업종명 또는 상세 산업명을 명시
    if fdr_sector:
        return fdr_sector
    if fdr_industry:
        ind = fdr_industry.split(',')[0].strip()
        return ind[:15]

    return '기타'


def detect_candle_patterns(df_hist):
    """상승장악형(Bullish Engulfing) 및 샛별형(Morning Star) 캔들 패턴 감지"""
    is_engulfing = False
    is_morning_star = False
    
    if len(df_hist) < 3:
        return False, False
        
    if HAS_TALIB:
        try:
            o = df_hist['Open'].values.astype(float)
            h = df_hist['High'].values.astype(float)
            l = df_hist['Low'].values.astype(float)
            c = df_hist['Close'].values.astype(float)
            
            engullf = talib.CDLENGULFING(o, h, l, c)
            if len(engullf) > 0 and engullf[-1] == 100:
                is_engulfing = True
                
            m_star = talib.CDLMORNINGSTAR(o, h, l, c)
            if len(m_star) > 0 and m_star[-1] == 100:
                is_morning_star = True
        except Exception as e:
            print(f"  ⚠️ CDL Pattern Check via TA-Lib failed: {e}")
            
    if not HAS_TALIB or (not is_engulfing and not is_morning_star):
        try:
            prev_o = float(df_hist['Open'].iloc[-2])
            prev_c = float(df_hist['Close'].iloc[-2])
            curr_o = float(df_hist['Open'].iloc[-1])
            curr_c = float(df_hist['Close'].iloc[-1])
            
            if prev_c < prev_o and curr_c > curr_o:
                if curr_c >= prev_o and curr_o <= prev_c:
                    if (curr_c - curr_o) > (prev_o - prev_c):
                        is_engulfing = True
                        
            o1, c1 = float(df_hist['Open'].iloc[-3]), float(df_hist['Close'].iloc[-3])
            o2, c2 = float(df_hist['Open'].iloc[-2]), float(df_hist['Close'].iloc[-2])
            o3, c3 = float(df_hist['Open'].iloc[-1]), float(df_hist['Close'].iloc[-1])
            
            if c1 < o1 and (o1 - c1) / o1 >= 0.015:
                if abs(o2 - c2) / o2 <= 0.004:
                    if c3 > o3 and c3 > (o1 + c1) / 2:
                        is_morning_star = True
        except Exception:
            pass
            
    return is_engulfing, is_morning_star


def detect_bearish_patterns(df_hist):
    """최근 3~5거래일 데이터를 활용해 하락 반전 패턴 수학적 감지"""
    if len(df_hist) < 5:
        return False, False, False
        
    is_bearish_engulfing = False
    is_evening_star = False
    is_bearish_pinbar = False
    
    o = df_hist['Open'].values.astype(float)
    h = df_hist['High'].values.astype(float)
    l = df_hist['Low'].values.astype(float)
    c = df_hist['Close'].values.astype(float)
    v = df_hist['Volume'].values.astype(float) if 'Volume' in df_hist.columns else np.zeros(len(df_hist))
    
    if HAS_TALIB:
        try:
            engulf = talib.CDLENGULFING(o, h, l, c)
            if len(engulf) > 0 and engulf[-1] == -100:
                is_bearish_engulfing = True
                
            e_star = talib.CDLEVENINGSTAR(o, h, l, c)
            if len(e_star) > 0 and e_star[-1] == -100:
                is_evening_star = True
        except Exception as e:
            print(f"  ⚠️ CDL Bearish Pattern Check via TA-Lib failed: {e}")
            
    # Fallback 수식
    if not is_bearish_engulfing or not is_evening_star:
        try:
            prev_o = float(df_hist['Open'].iloc[-2])
            prev_c = float(df_hist['Close'].iloc[-2])
            curr_o = float(df_hist['Open'].iloc[-1])
            curr_c = float(df_hist['Close'].iloc[-1])
            
            # 1) 하락 장악형 (전일 양봉 몸통을 오늘 음봉 몸통이 장악)
            if prev_c > prev_o and curr_c < curr_o:
                if curr_o >= prev_c and curr_c <= prev_o:
                    if (curr_o - curr_c) > (prev_c - prev_o):
                        is_bearish_engulfing = True
                        
            # 2) 석별형 (3일 전 장대양봉 → 2일 전 스타 도지 → 1일 전 장대음봉)
            o1, c1 = float(df_hist['Open'].iloc[-3]), float(df_hist['Close'].iloc[-3])
            o2, c2 = float(df_hist['Open'].iloc[-2]), float(df_hist['Close'].iloc[-2])
            o3, c3 = float(df_hist['Open'].iloc[-1]), float(df_hist['Close'].iloc[-1])
            
            if c1 > o1 and (c1 - o1) / o1 >= 0.015:  # 3일 전 장대양봉
                if abs(o2 - c2) / o2 <= 0.004:         # 2일 전 도지/스타
                    if c3 < o3 and c3 < (o1 + c1) / 2: # 1일 전 장대음봉이 양봉의 절반 이하로 하락
                        is_evening_star = True
        except Exception:
            pass

    # 3) 위꼬리 고거래량 음봉 (Bearish Pinbar with Volume Spike)
    try:
        curr_o = float(df_hist['Open'].iloc[-1])
        curr_c = float(df_hist['Close'].iloc[-1])
        curr_h = float(df_hist['High'].iloc[-1])
        curr_l = float(df_hist['Low'].iloc[-1])
        
        body = abs(curr_c - curr_o)
        rng = curr_h - curr_l
        upper_shadow = curr_h - max(curr_o, curr_c)
        
        if rng > 0 and upper_shadow >= rng * 0.5 and curr_c <= curr_o * 1.01:
            if len(df_hist) >= 6:
                vol_today = float(v[-1])
                avg_vol_5d = float(np.mean(v[-6:-1]))
                if avg_vol_5d > 0 and vol_today >= avg_vol_5d * 2.0:
                    is_bearish_pinbar = True
    except Exception:
        pass
        
    return is_bearish_engulfing, is_evening_star, is_bearish_pinbar


def detect_double_bottom(df_hist):
    """최근 60거래일 데이터를 활용해 이중 바닥(쌍바닥) 패턴 수학적 감지"""
    if len(df_hist) < 40:
        return False
        
    try:
        df_60 = df_hist.tail(60).copy()
        prices = df_60['Close'].values
        lows = df_60['Low'].values
        
        idx1 = int(np.argmin(lows))
        L_min1 = lows[idx1]
        
        mask = np.ones(len(lows), dtype=bool)
        start_mask = max(0, idx1 - 8)
        end_mask = min(len(lows), idx1 + 9)
        mask[start_mask:end_mask] = False
        
        if not np.any(mask):
            return False
            
        remaining_indices = np.where(mask)[0]
        idx2_rel = np.argmin(lows[mask])
        idx2 = int(remaining_indices[idx2_rel])
        L_min2 = lows[idx2]
        
        if abs(idx1 - idx2) < 10:
            return False
            
        price_diff_ratio = abs(L_min1 - L_min2) / max(L_min1, L_min2)
        if price_diff_ratio > 0.025:
            return False
            
        mid_start = min(idx1, idx2)
        mid_end = max(idx1, idx2)
        mid_high = np.max(prices[mid_start:mid_end])
        
        if mid_high < max(L_min1, L_min2) * 1.035:
            return False
            
        curr_price = float(df_hist['Close'].iloc[-1])
        base_bottom = min(L_min1, L_min2)
        if base_bottom * 1.015 <= curr_price <= base_bottom * 1.18:
            return True
    except Exception:
        pass
        
    return False


def detect_triangle_convergence(df_hist):
    """최근 40거래일의 변동성 축소 비율(Volatility Contraction)을 활용한 삼각 수렴 패턴 수학적 감지"""
    if len(df_hist) < 35:
        return False
        
    try:
        df_40 = df_hist.tail(40).copy()
        df_40['range_pct'] = (df_40['High'] - df_40['Low']) / df_40['Close']
        
        vol_prev = df_40['range_pct'].iloc[0:20].mean()
        vol_curr = df_40['range_pct'].iloc[20:40].mean()
        
        if vol_curr < vol_prev * 0.75:
            vol_5d = df_40['range_pct'].tail(5).mean()
            if vol_5d < vol_curr * 0.85:
                highs = df_40['High'].tail(20).values
                lows = df_40['Low'].tail(20).values
                
                high_slope = np.polyfit(np.arange(20), highs, 1)[0]
                low_slope = np.polyfit(np.arange(20), lows, 1)[0]
                
                if high_slope < 0 and low_slope > 0:
                    return True
    except Exception:
        pass
        
    return False


def collect_quant_final(token, df_hd, df_full):
    """Quant 점수 계산 - 선행 매수 타이밍 포착 전용 스크리너

    [목적]
    이 함수는 단순한 당일 강세 종목 선별이 아닌, 아직 시장의 본격적인 주목을 받기 전
    '선행 매수(Early Entry)' 타이밍을 포착하기 위한 종합 퀀트 스코어를 산출합니다.

    [점수 구성 - 총 100점 만점]
    - Score_Momentum (20점): 당일 등락률(10) + 5거래일 누적 추세(10) → 지속적 상승 흐름 확인
    - Score_Supply   (30점): 시가총액 대비 외인+기관 순매수 비율 → 스마트머니 선행 유입 포착
    - Score_Volume   (20점): 평균 대비 거래대금 급증률 (최소 10억 허들) → 관심도 증가 조기 감지
    - Score_MA       (15점): 이평선 배열 + 60일선 필터 + 이격도/수렴 보정 → 추세 구조 확인
    - Score_Candle   (15점): 당일 캔들 매수세 강도 → 진입 타이밍 최적화

    [매크로 보정 로직 - 3중 레이어 사이드카 대응 구조]
    ● Layer 1 - 방향성 패널티: 당일/3일/5일 누적 낙폭 기반 (기존 방식)
    ● Layer 2 - 변동성 레짐 패널티: 10일 일간 변동성(σ) 기반 (신규)
      → 사이드카처럼 매수/매도가 교대로 발생해 방향성이 상쇄될 때도 포착
      → σ > 2.0% (연환산 ~32%) 이면 고변동성 레짐으로 별도 패널티 부여
    ● Layer 3 - 장중 충격 감지: 당일 고저폭/전일종가 비율 기반 (신규)
      → 사이드카가 장중 발동되었으나 종가가 회복된 경우에도 감지
    - USD/KRW 환율 급등 감지: 환율 5일 +3% 이상 시 섹터별 차등 적용
    - 유가 급등 감지: 정유 에너지 섹터 수혜 / 항공·운송 패널티
    - 종목별 변동성 조정: 20일 연환산 변동성 30% 초과 시 점수 하향
    - 섹터 가중치: 매크로 국면에 따라 섹터별 점수 계수를 차등 적용
    - 이중 신호 중복 보정: 거래대금 급증과 가격 급등이 동시에 만점일 때 과대평가 방지
    """
    print('🎯 선행 매수 퀀트 스코어 계산 중...')
    if df_hd.empty:
        return pd.DataFrame()

    # ── 매크로 팩터 사전 수집 ────────────────────────────────────────
    # Layer 1: 방향성 패널티 (누적 낙폭)
    layer1_penalty = 1.0
    # Layer 2: 변동성 레짐 패널티 (방향성과 독립적 - 사이드카 상쇄 문제 해결)
    layer2_vol_regime = 1.0
    # Layer 3: 당일 장중 충격 감지 패널티
    layer3_intraday = 1.0

    market_condition = '중립'
    usd_krw_chg_5d = 0.0
    oil_surge = False

    try:
        start_mkt = (datetime.now(KST) - timedelta(days=20)).strftime('%Y-%m-%d')
        df_ks  = fdr.DataReader('KS11', start_mkt)
        df_kq  = fdr.DataReader('KQ11', start_mkt)
        df_usd = fdr.DataReader('USD/KRW', start_mkt)

        def last_chg(df):
            return float(df['Change'].iloc[-1] * 100) if not df.empty and 'Change' in df.columns else 0

        def cumret(df, n):
            if len(df) < n + 1: return 0
            p0 = float(df['Close'].iloc[-(n+1)])
            p1 = float(df['Close'].iloc[-1])
            return ((p1 - p0) / p0 * 100) if p0 > 0 else 0

        ks_1d = last_chg(df_ks); kq_1d = last_chg(df_kq); avg_1d = (ks_1d + kq_1d) / 2
        avg_3d = (cumret(df_ks, 3) + cumret(df_kq, 3)) / 2
        avg_5d = (cumret(df_ks, 5) + cumret(df_kq, 5)) / 2

        # ── Layer 1: 방향성 패널티 (기존 로직 유지) ──────────────────
        if avg_1d <= -1.5 or avg_3d <= -3.0 or avg_5d <= -5.0:
            layer1_penalty = 0.80
            market_condition = f'하락위기 (1d:{avg_1d:.1f}% 3d:{avg_3d:.1f}% 5d:{avg_5d:.1f}%)'
        elif avg_1d <= -0.5 or avg_3d <= -1.5 or avg_5d <= -3.0:
            layer1_penalty = 0.90
            market_condition = f'약세 (1d:{avg_1d:.1f}% 3d:{avg_3d:.1f}% 5d:{avg_5d:.1f}%)'
        elif avg_1d >= 1.0 and avg_3d >= 2.0:
            market_condition = f'강세 (1d:{avg_1d:.1f}% 3d:{avg_3d:.1f}% 5d:{avg_5d:.1f}%)'
        else:
            market_condition = f'중립 (1d:{avg_1d:.1f}% 3d:{avg_3d:.1f}% 5d:{avg_5d:.1f}%)'

        # ── Layer 2: 변동성 레짐 패널티 (사이드카 상쇄 핵심 해결) ──────
        # 최근 10일 KOSPI 일간 수익률의 표준편차로 레짐 판별
        # → 매수/매도 사이드카가 교대로 발생해 방향성이 0%에 수렴해도
        #   변동성(σ)은 높게 유지되므로 이 레이어에서 독립적으로 포착
        if len(df_ks) >= 11:
            ks_10d_std = df_ks['Change'].tail(10).std() * 100  # 일간 σ (%)
            kq_10d_std = df_kq['Change'].tail(10).std() * 100
            avg_10d_std = (ks_10d_std + kq_10d_std) / 2

            if avg_10d_std >= 2.5:
                # 일간 σ ≥ 2.5% (연환산 ≈ 40%↑): 사이드카 빈발 극단 레짐
                layer2_vol_regime = 0.80
                market_condition += f' | ⚡극단변동성(σ={avg_10d_std:.1f}%)'
            elif avg_10d_std >= 2.0:
                # 일간 σ ≥ 2.0% (연환산 ≈ 32%↑): 고변동성 레짐
                layer2_vol_regime = 0.88
                market_condition += f' | 고변동성(σ={avg_10d_std:.1f}%)'
            elif avg_10d_std >= 1.5:
                # 일간 σ ≥ 1.5% (연환산 ≈ 24%↑): 주의 레짐
                layer2_vol_regime = 0.95
                market_condition += f' | 주의(σ={avg_10d_std:.1f}%)'

        # ── Layer 3: 당일 장중 충격 감지 ─────────────────────────────
        # 고가-저가 폭이 전일 종가 대비 4% 이상이면 장중 사이드카 수준의
        # 극단 변동이 발생했을 가능성이 높음 (종가 회복 여부와 무관하게 감지)
        if len(df_ks) >= 2:
            ks_h  = float(df_ks['High'].iloc[-1])
            ks_l  = float(df_ks['Low'].iloc[-1])
            ks_pc = float(df_ks['Close'].iloc[-2])
            intraday_range = ((ks_h - ks_l) / ks_pc * 100) if ks_pc > 0 else 0
            if intraday_range >= 5.0:
                # 코스피 당일 고저폭 5% 이상: 사이드카 발동 수준의 장중 충격
                layer3_intraday = 0.88
                market_condition += f' | 장중충격(범위{intraday_range:.1f}%)'
            elif intraday_range >= 3.5:
                layer3_intraday = 0.94

        # 최종 시장 패널티: 3개 레이어 곱셈 적용
        market_penalty = round(layer1_penalty * layer2_vol_regime * layer3_intraday, 3)

        # USD/KRW 5일 변동률 계산
        if not df_usd.empty and len(df_usd) >= 6:
            usd_p0 = float(df_usd['Close'].iloc[-6])
            usd_p1 = float(df_usd['Close'].iloc[-1])
            usd_krw_chg_5d = ((usd_p1 - usd_p0) / usd_p0 * 100) if usd_p0 > 0 else 0

        # 유가 급등 감지
        try:
            df_oil_proxy = fdr.DataReader('096770', start_mkt)
            if not df_oil_proxy.empty and len(df_oil_proxy) >= 6:
                oil_surge = cumret(df_oil_proxy, 5) >= 5.0
        except:
            oil_surge = False

        print(f'  📊 시장 국면: {market_condition}')
        print(f'  🔢 패널티: L1(방향)x{layer1_penalty} × L2(변동성)x{layer2_vol_regime} × L3(장중)x{layer3_intraday} = x{market_penalty}')
        print(f'  💱 USD/KRW 5일 변동: {usd_krw_chg_5d:+.2f}% | 유가급등: {oil_surge}')
    except Exception as e:
        print(f'  ⚠️ 매크로 데이터 조회 실패 (기본값 적용): {e}')

    # ── 섹터별 가중치 산출 (매크로 국면 연동) ────────────────────────
    def get_sector_multiplier(sector):
        """매크로 환경에 따른 섹터별 점수 가중치 반환"""
        m = 1.0  # 기본 중립

        # 환율 급등 국면 (USD/KRW +3% 이상): 수출주 수혜, 내수 패널티
        if usd_krw_chg_5d >= 3.0:
            if sector == '반도체':   m *= 1.10  # 달러 매출 → 환차익 수혜
            elif sector == '자동차': m *= 1.05  # 수출 수혜
            elif sector in ('내수', '바이오', '건설'): m *= 0.90  # 수입 원가↑

        # 환율 급락 국면 (USD/KRW -3% 이하): 반대 적용
        elif usd_krw_chg_5d <= -3.0:
            if sector == '반도체':   m *= 0.93
            elif sector in ('내수',): m *= 1.05

        # 유가 급등 국면: 정유 수혜 / 항공·운송 패널티
        if oil_surge:
            if sector == '에너지':     m *= 1.10
            elif sector == '항공운송': m *= 0.82  # 항공유 원가 급등
            elif sector == '반도체':   m *= 0.95  # 전력비 부담

        # 시장 위기 국면: 금융·방어주 상대 강세
        if market_penalty <= 0.80:
            if sector == '금융':       m *= 0.95  # 금리 불확실성
            if sector == '통신':       m *= 1.03  # 경기 방어

        return round(m, 3)

    print(f'  📊 시장 국면: {market_condition} (점수 계수: x{market_penalty})')

    rows = []
    # 60일선(MA60) 및 가격 이력을 충분히 조회하기 위해 시작 날짜 계산 (안전하게 100일 전으로 설정)
    start_date = (datetime.now(KST) - timedelta(days=100)).strftime('%Y-%m-%d')

    for _, row in df_hd.iterrows():
        code = str(row.get('Code', '')).zfill(6)
        name = row.get('Name', '')
        
        # ── ETF, ETN, 커버드콜, 선물, 인버스, 레버리지, 스팩 등 파생 및 펀드 상품 필터링 제외 ──
        name_lower = name.lower()
        exclude_keywords = [
            'etf', 'etn', '선물', '인버스', '레버리지', '커버드콜', '스팩', 
            'kodex', 'tiger', 'kbstar', 'ace', 'sol', 'hanaro', 'kosef', 
            'plus', 'rise', 'woori', 'arirang', '곱버스'
        ]
        if any(kw in name_lower for kw in exclude_keywords):
            continue
            
        # 이전 루프의 변수 오염을 막기 위한 초기화
        df_hist = None
        today_amount = 0

        # 1. 가격 모멘텀 점수 (최대 20점) [선행 매수 최적 구간 재설계]
        # 선행 매수 관점: +1~+3% 구간이 가장 이상적 진입 신호 (만점 10점)
        # +5% 이상 급등은 추격 위험이 있어 선형 감소 적용 (단, 6점 하한선 유지)
        # → 외국인/기관 주도 급등은 수급 점수로 이미 반영되므로 모멘텀만 과도하게 낮추지 않음
        change = float(row.get('ChagesRatio', 0))
        if 1.0 <= change < 3.0:
            score_day = 10.0                          # 이상적 선행 진입 구간 (소폭 상승)
        elif change >= 3.0:
            # +3%=9점, +5%=8점, +7%=7점 순으로 선형 감소, 최소 6점 하한 유지
            score_day = max(6.0, 10.0 - (change - 1.0) * 0.5)
        elif 0.0 <= change < 1.0:
            score_day = 8.0                           # 보합~미세 상승 (눌림목 진입 가능)
        elif -1.0 <= change < 0.0:
            score_day = 6.0                           # 소폭 조정 (건강한 눌림목 가능)
        elif -3.0 <= change < -1.0:
            score_day = 2.0                           # 하락세
        else:
            score_day = 0.0                           # 급락 (-3% 이하)
        # 5일 누적 모멘텀: FDR 조회 전이므로 일단 중립값 5점으로 초기화 (아래 FDR 블록에서 갱신)
        score_5d = 5.0
        score_momentum = score_day + score_5d  # FDR 블록에서 최종 갱신됨

        # 2. 수급 점수 (최대 30점) [개선: 로그 스케일 시총 보정으로 소형주 과대평가 방지]
        # 외인+기관 합산 순매수 금액(원화) 기준. KIS API 순매수량은 주식수이므로 종가를 곱해 금액 계산.
        close = float(row.get('Close', 0))
        foreign_qty = float(row.get('Foreign_Net', 0))
        inst_qty = float(row.get('Institutional_Net', 0))
        marcap = float(row.get('Marcap', 0))

        net_buy_amount = (foreign_qty + inst_qty) * close
        # [개선] 기존 고정 임계값(0.05%)은 소형주/대형주 체급 무관하게 동일해 소형주 과대평가 유발
        # 로그 스케일 시총 기반 동적 임계값: 대형주일수록 같은 점수에 더 많은 매수 필요
        # 시총 1천억(10^11) → threshold≈0.03%, 1조(10^12) → 0.05%, 10조(10^13) → 0.07%, 100조(10^14) → 0.10%
        if marcap > 0:
            net_ratio = (net_buy_amount / marcap) * 100
            log_adj = float(np.log10(max(marcap, 50_000_000_000)) - 11.0)  # 0 at 1천억
            threshold = max(0.03, min(0.12, 0.05 + log_adj * 0.02))       # 0.03~0.12% 범위
            score_supply = min(30, max(0, (net_ratio / threshold) * 15 + 15))
        else:
            # 시가총액 정보가 없을 경우 절대 금액 방식 폴백 (+5억원 이상 30점)
            score_supply = min(30, max(0, net_buy_amount / 100_000_000 * 3 + 15))

        # 기본 차트 점수 및 거래대금 증가율 초기화 (FDR 실패 대비)
        score_volume = 10.0
        score_ma = 7.5
        score_candle = 7.5

        # fdr을 통한 일봉 데이터 조회 (MA 및 캔들, 거래대금 증가율 계산용)
        try:
            df_hist = fdr.DataReader(code, start_date)

            # ── [신규상장 종목 제외] 상장 후 약 3개월(60영업일) 미만 종목은 퀀트 유니버스에서 제외 ──
            # 상장 초기에는 주가 급등락이 빈번하고 기준 이평선/거래대금 비교값이 왜곡되어 퀀트 신뢰도 저하
            # FDR 데이터가 없거나 60행 미만이면 신규 상장 종목으로 판단
            IPO_MIN_DAYS = 60  # 최소 60영업일(약 3개월) 거래 이력 요구
            if df_hist is None or df_hist.empty or len(df_hist) < IPO_MIN_DAYS:
                print(f'  ⏭️ [{name}({code})] 신규상장 종목 제외 (데이터 {len(df_hist) if df_hist is not None and not df_hist.empty else 0}일, 최소 {IPO_MIN_DAYS}일 필요)')
                continue

            if not df_hist.empty and len(df_hist) >= 5:
                # 3. 거래대금 증가율 점수 (최대 20점) [개선: 절대 거래대금 최소 허들 적용]
                # 거래대금 = 종가 * 거래량
                df_hist['Amount_Hist'] = df_hist['Close'] * df_hist['Volume']
                today_amount = df_hist['Amount_Hist'].iloc[-1]

                # [개선] 20일+60일 기준 중 더 보수적(높은) 평균 사용 → 최근 단기 급등으로 기준치가 낮아지는 왜곡 방지
                hist_len = len(df_hist)
                avg_20d = df_hist['Amount_Hist'].iloc[max(0, hist_len-21):hist_len-1].mean()
                avg_60d_range = df_hist['Amount_Hist'].iloc[max(0, hist_len-61):hist_len-1]
                avg_60d = avg_60d_range.mean() if len(avg_60d_range) >= 20 else avg_20d
                avg_amount = max(avg_20d, avg_60d)  # 더 높은(보수적) 기준 적용
                if pd.isna(avg_amount) or avg_amount <= 0:
                    avg_amount = today_amount

                # 절대 거래대금 최소 허들: 당일 거래대금 10억원 미만이면 소외주 펌핑으로 판단, 최대 5점 제한
                MIN_AMOUNT_THRESHOLD = 1_000_000_000  # 10억원
                if today_amount < MIN_AMOUNT_THRESHOLD:
                    score_volume = min(5, max(0, (today_amount / MIN_AMOUNT_THRESHOLD) * 5))
                else:
                    surge_ratio = today_amount / avg_amount if avg_amount > 0 else 1.0
                    score_volume = min(20, max(0, (surge_ratio - 1.0) * 10 + 10))

                    # [신규] 신선도 보정: 최근 5 거래일 이내 이미 2배 급증이 있었다면 -30% 감점
                    # → 이미 한 번 터진 거래대금 재급증은 선행 신호가 아닌 뒤늦은 추격 가능성
                    recent_5d_max = df_hist['Amount_Hist'].iloc[max(0, hist_len-6):hist_len-1].max()
                    if pd.notna(recent_5d_max) and recent_5d_max > avg_amount * 2.0:
                        score_volume = round(score_volume * 0.7, 1)  # 이미 급증 경험 → 30% 감점

                # [개선] 가격 모멘텀 점수 - 5일 누적 등락률 파트 갱신
                # 최근 5일(오늘 포함) 종가 기준 누적 수익률 계산
                if len(df_hist) >= 6:
                    price_5d_ago = float(df_hist['Close'].iloc[-6])  # 5거래일 전 종가
                    price_now = float(df_hist['Close'].iloc[-1])
                    change_5d = ((price_now - price_5d_ago) / price_5d_ago * 100) if price_5d_ago > 0 else 0
                    # 5일 누적 +10% 이상 10점, -10% 이하 0점, 0%일 때 5점
                    score_5d = min(10, max(0, change_5d * 0.5 + 5))
                else:
                    score_5d = 5.0  # 이력 부족 시 중립값

                # 최종 모멘텀 점수 재계산 (당일 10점 + 5일 누적 10점)
                score_momentum = min(20, max(0, score_day + score_5d))

                # 4. 차트 기술적 점수 (최대 30점)
                # (1) 이동평균선 점수 (최대 15점)
                ma5 = df_hist['Close'].rolling(5).mean().iloc[-1]
                ma20 = df_hist['Close'].rolling(20).mean().iloc[-1] if len(df_hist) >= 20 else ma5
                ma60 = df_hist['Close'].rolling(60).mean().iloc[-1] if len(df_hist) >= 60 else ma20
                today_close = df_hist['Close'].iloc[-1]

                # [개선] 선행 매수 관점으로 이평선 점수 재설계
                # 기존: 완벽 정배열=15점(이미 많이 오른 상태), 골든크로스 직전=12점(선행 타이밍인데 낮은 점수)
                # 개선: 골든크로스 직전·20일선 눌림목 지지를 최우선 선행 신호로 재평가
                disparity_from_ma20 = (today_close / ma20 - 1.0) * 100 if ma20 > 0 else 0
                ma_spread = abs(ma5 - ma20) / ma20 if ma20 > 0 else 1.0

                if today_close > ma5 and today_close > ma20 and ma5 <= ma20:
                    score_ma = 14.0  # 역배열 돌파 (골든크로스 직전) → 선행 매수 최적!
                elif -2.0 <= disparity_from_ma20 <= 2.0 and today_close > ma20:
                    score_ma = 13.0  # 20일선 직상방 지지 (눌림목) → 선행 매수 최적!
                elif today_close > ma5 > ma20 and ma20 > ma60:
                    score_ma = 11.0  # 완벽 정배열 (이미 오른 상태, 추격 위험)
                elif today_close > ma5 > ma20 and ma20 <= ma60:
                    score_ma = 10.0  # 단기 정배열, 장기선 아래
                elif today_close > ma20 and today_close <= ma5:
                    score_ma = 7.0   # 20일선 지지, 5일선 아래 (단기 조정 중)
                elif today_close > ma5 and today_close <= ma20:
                    score_ma = 5.0   # 5일선 위이나 20일선 아래
                else:
                    score_ma = 0.0   # 완전 역배열

                # 가감점 필터 적용
                # 1) 대세 하락 필터: 60일선 아래에 있을 때 최대 점수 8점으로 제한
                if today_close <= ma60:
                    score_ma = min(8.0, score_ma)

                # 2) 이격도 과열 감점: 20일선 대비 15% 이상 괴리 시 -4점
                disparity = (today_close / ma20) * 100 if ma20 > 0 else 100
                if disparity >= 115:
                    score_ma -= 4.0

                # 3) 수렴 돌파 가점: 5일선과 20일선 3% 이내 수렴 후 종가가 두 선 모두 상회 시 +2점
                if ma_spread <= 0.03 and today_close > ma5 and today_close > ma20:
                    score_ma += 2.0

                # 0~15점 범위 보정
                score_ma = min(15.0, max(0.0, score_ma))

                # (2) 캔들 패턴 점수 (최대 15점)
                o = float(df_hist['Open'].iloc[-1])
                h = float(df_hist['High'].iloc[-1])
                l = float(df_hist['Low'].iloc[-1])
                c = float(df_hist['Close'].iloc[-1])
                prev_close = float(df_hist['Close'].iloc[-2]) if len(df_hist) >= 2 else o

                # 점상한가 / 점하한가 예외 처리 (고가와 저가가 같은 경우)
                if h == l:
                    if c > prev_close:
                        score_candle = 15.0  # 점상한가 (매수세 최강)
                    else:
                        score_candle = 0.0   # 점하한가 (매도세 최강)
                else:
                    body = c - o
                    rng = h - l
                    lower_shadow = min(o, c) - l
                    upper_shadow = h - max(o, c)

                    # 1) 도지형 판별 임계값 도입 (시가 대비 몸통 크기가 0.2% 이하인 경우 도지로 분류)
                    is_doji = (abs(body) / o <= 0.002) if o > 0 else (body == 0)

                    if is_doji:
                        if lower_shadow > rng * 0.5:
                            score_candle = 10.0  # 밑꼬리가 긴 도지 (지지세 유입)
                        else:
                            score_candle = 5.0   # 일반 도지
                    elif body > 0:  # 양봉
                        if lower_shadow > body * 0.5:
                            score_candle = 15.0  # 아래꼬리가 긴 망치형 양봉 (매수세 강함)
                        elif upper_shadow > body and (body / o >= 0.005):
                            # 몸통이 시가 대비 0.5% 이상으로 유의미할 때만 위꼬리 감점 적용
                            score_candle = 8.0   # 위꼬리가 긴 양봉 (매물 저항)
                        elif upper_shadow > body * 2:
                            # 몸통이 미세할 때는 위꼬리가 몸통의 2배 이상일 때만 감점
                            score_candle = 8.0
                        else:
                            score_candle = 12.0  # 일반 양봉 / 장대양봉
                    else:  # 음봉
                        # [개선] 거래량으로 음봉 품질 구분: 저거래량 음봉은 건강한 눌림목, 고거래량 음봉은 매도 압력
                        vol_today = float(df_hist['Volume'].iloc[-1]) if 'Volume' in df_hist.columns else 0
                        avg_vol_5d = df_hist['Volume'].iloc[max(0, hist_len-6):hist_len-1].mean() if 'Volume' in df_hist.columns else vol_today
                        avg_vol_5d = avg_vol_5d if pd.notna(avg_vol_5d) and avg_vol_5d > 0 else vol_today

                        if lower_shadow > abs(body) * 1.5:
                            # 아래꼬리 긴 음봉 - 거래량 동반 여부로 신호 강도 구분
                            score_candle = 10.0 if vol_today >= avg_vol_5d else 8.0
                        elif vol_today < avg_vol_5d * 0.7:
                            score_candle = 5.0   # 저거래량 조정 음봉 = 건강한 눌림목 (선행 매수 기회)
                        elif vol_today < avg_vol_5d:
                            score_candle = 3.0   # 평균 이하 거래량 음봉 (보통 조정)
                        else:
                            score_candle = 0.0   # 고거래량 하락 = 매도 압력 강함

                # ── 캔들 패턴 가산점 적용 (상승장악형/샛별형) ─────────────────────
                is_engulfing, is_morning_star = detect_candle_patterns(df_hist)
                if is_engulfing:
                    score_candle += 4.0
                    print(f"  🔥 [{name}] 상승장악형 캔들 패턴 감지 (+4.0점)")
                elif is_morning_star:
                    score_candle += 5.0
                    print(f"  🔥 [{name}] 샛별형 캔들 패턴 감지 (+5.0점)")
                
                score_candle = min(15.0, max(0.0, score_candle))

        except Exception as e:
            print(f'  ⚠️ [{name}] 가격 이력 조회 실패: {e}')

        # ── 이중 신호 중복 측정 보정 [개선: 극단적 중복 신호만 보정] ──────────────────────
        # 거래대금 만점권(≥14점)과 가격 급등 만점권(≥14점)이 동시에 나타날 때만 보정
        # → 중간 강도(12점)까지 보정하면 일반적인 강세 종목도 패널티를 받는 부작용 발생
        if score_volume >= 14 and score_momentum >= 14:
            excess_v = score_volume - 14
            excess_m = score_momentum - 14
            score_volume   = max(14, score_volume   - excess_v * 0.5)
            score_momentum = max(14, score_momentum - excess_m * 0.5)

        # ── 섹터 분류 및 매크로 가중치 적용 ──────────────────────────
        fdr_sector = row.get('FDR_Sector', '')
        fdr_industry = row.get('FDR_Industry', '')
        sector = _classify_sector(code, name, fdr_sector, fdr_industry)

        # 만약 로컬/FDR 분류에서 '기타'로 분류되었을 경우, KIS HTS API 실시간 조회 폴백 (10-15개 소수 종목만 동적 호출)
        if sector == '기타':
            hts_sector = fetch_stock_sector(token, code)
            if hts_sector:
                # HTS 업종명을 기반으로 9대 핵심 섹터 분류 재시도
                sector = _classify_sector(code, name, hts_sector)
                if sector == '기타':
                    sector = hts_sector  # 재분류 불가 시 HTS 업종명 그대로 사용 (기타 방지)
            time.sleep(0.05)  # TPS 방지

        sector_mult = get_sector_multiplier(sector)

        # ── 변동성 조정 패널티 (리스크 조정 수익률 관점) ──────────────
        # 20일 연환산 변동성(σ)이 30% 초과 시 고변동성 종목 점수 하향
        # 급등락장에서 변동성 큰 종목의 역선택 문제를 방지함
        vol_penalty = 1.0
        try:
            if df_hist is not None and len(df_hist) >= 20:
                daily_returns = df_hist['Close'].pct_change().dropna()
                vol_20d = daily_returns.tail(20).std() * (252 ** 0.5)  # 연환산 변동성
                if vol_20d > 0.5:    vol_penalty = 0.80  # 50% 초과: 극고변동성 강한 패널티
                elif vol_20d > 0.35: vol_penalty = 0.90  # 35~50%: 고변동성 패널티
                elif vol_20d > 0.25: vol_penalty = 0.95  # 25~35%: 약한 패널티
        except:
            vol_penalty = 1.0

        # ── 중기 차트 패턴 가산점 적용 (이중 바닥 / 삼각 수렴) ───────────────
        chart_bonus = 0.0
        try:
            if df_hist is not None and len(df_hist) >= 40:
                is_double_bottom = detect_double_bottom(df_hist)
                is_triangle = detect_triangle_convergence(df_hist)
                
                if is_double_bottom:
                    chart_bonus += 4.0
                    print(f"  🚀 [{name}] 이중 바닥(쌍바닥) 차트 패턴 감지 (+4.0점)")
                if is_triangle:
                    chart_bonus += 3.0
                    print(f"  🚀 [{name}] 삼각 수렴 변동성축소 패턴 감지 (+3.0점)")
        except Exception as chart_err:
            print(f"  ⚠️ [{name}] 차트 패턴 분석 중 예외 발생: {chart_err}")

        # ── 합산 점수 + 전체 보정 계수 적용 ──────────────────────────
        # 적용 순서: (원점수 + 차트보너스) → 이중신호보정 → 변동성조정 → 섹터가중치 → 시장국면패널티
        raw_score   = score_momentum + score_supply + score_volume + score_ma + score_candle + chart_bonus
        total_score = round(raw_score * vol_penalty * sector_mult * market_penalty, 1)

        # ── [고도화] 매도 퀀트 점수(Sell Score) 산출 (최대 100점) ─────────────────────
        score_sell = 0.0
        try:
            if df_hist is not None and not df_hist.empty:
                # 1) 하락 모멘텀 점수 (최대 20점)
                score_sell_mom = 0.0
                if change < 0:
                    score_sell_mom = min(10.0, abs(change) * 2.0)  # -5% 하락 시 10점 만점
                if len(df_hist) >= 6:
                    price_5d_ago = float(df_hist['Close'].iloc[-6])
                    price_now = float(df_hist['Close'].iloc[-1])
                    ret_5d = ((price_now - price_5d_ago) / price_5d_ago * 100) if price_5d_ago > 0 else 0
                    if ret_5d < -10:
                        score_sell_mom += 10.0  # 단기 폭락
                    elif ret_5d > 25:
                        score_sell_mom += 10.0  # 극단적 과열 (이격 과다)
                score_sell += min(20.0, score_sell_mom)

                # 2) 수급 이탈 점수 (최대 30점)
                score_sell_supply = 0.0
                net_sell_qty = - (foreign_qty + inst_qty)
                if net_sell_qty > 0:
                    net_sell_amount = net_sell_qty * close
                    if marcap > 0:
                        sell_ratio = (net_sell_amount / marcap) * 100
                        score_sell_supply = min(30.0, (sell_ratio / 0.05) * 15)  # 시총 대비 0.1% 순매도 시 30점
                    else:
                        score_sell_supply = min(30.0, net_sell_amount / 100_000_000 * 3)
                score_sell += score_sell_supply

                # 3) 거래량 터진 음봉 점수 (최대 20점)
                score_sell_vol = 0.0
                if change < 0 and 'Volume' in df_hist.columns and len(df_hist) >= 20:
                    df_hist['Amount_Hist'] = df_hist['Close'] * df_hist['Volume']
                    today_amt = df_hist['Amount_Hist'].iloc[-1]
                    hist_l = len(df_hist)
                    avg_amt_20d = df_hist['Amount_Hist'].iloc[max(0, hist_l-21):hist_l-1].mean()
                    if avg_amt_20d > 0:
                        vol_surge = today_amt / avg_amt_20d
                        if vol_surge >= 2.0:
                            score_sell_vol = min(20.0, (vol_surge - 1.0) * 10)
                score_sell += score_sell_vol

                # 4) 기술적 하락 및 하락 패턴 점수 (최대 30점)
                score_sell_tech = 0.0
                ma5_val = df_hist['Close'].rolling(5).mean().iloc[-1]
                ma20_val = df_hist['Close'].rolling(20).mean().iloc[-1] if len(df_hist) >= 20 else ma5_val
                if today_close < ma5_val and today_close < ma20_val:
                    if ma5_val <= ma20_val:
                        score_sell_tech += 15.0  # 데드크로스/역배열
                    else:
                        score_sell_tech += 8.0   # 5/20일선 모두 하회
                
                disp_ma20 = (today_close / ma20_val) * 100 if ma20_val > 0 else 100
                if disp_ma20 >= 115:
                    score_sell_tech += 15.0  # 이격 과열

                is_bear_engulf, is_eve_star, is_bear_pin = detect_bearish_patterns(df_hist)
                if is_bear_engulf:
                    score_sell_tech += 10.0
                    print(f"  💀 [{name}] 하락장악형 캔들 패턴 감지 (매도점수 +10.0)")
                if is_eve_star:
                    score_sell_tech += 12.0
                    print(f"  💀 [{name}] 석별형 캔들 패턴 감지 (매도점수 +12.0)")
                if is_bear_pin:
                    score_sell_tech += 8.0
                    print(f"  💀 [{name}] 위꼬리 고거래량 음봉 패턴 감지 (매도점수 +8.0)")

                score_sell += min(30.0, score_sell_tech)
        except Exception as sell_score_err:
            print(f"  ⚠️ [{name}] 매도 점수 산출 중 예외 발생: {sell_score_err}")

        sell_score = round(min(100.0, max(0.0, score_sell)), 1)

        # FDR 당일 거래대금(today_amount)이 산출되어 있으면 사용, 없으면 df_hd의 Amount 사용 (단위: 원)
        amount = today_amount if today_amount > 0 else float(row.get('Amount', 0))

        rows.append({
            'Code':             code,
            'Name':             name,
            'Total_Score':      total_score,
            'Sell_Score':       sell_score,
            'Score_Momentum':   round(score_momentum, 1),
            'Score_Supply':     round(score_supply, 1),
            'Score_Volume':     round(score_volume, 1),
            'Score_MA':         round(score_ma, 1),
            'Score_Candle':     round(score_candle, 1),
            'Close':            close,
            'ChagesRatio':      change,
            'Amount':           amount,          # 거래대금 컬럼 추가
            'Sector':           sector,          # 섹터 분류
            'Sector_Mult':      sector_mult,     # 섹터 가중치 계수
            'Vol_Penalty':      vol_penalty,     # 변동성 패널티 계수
            'Market_Penalty':   market_penalty,  # 시장 패널티 계수
            'Market_Condition': market_condition,
        })
        time.sleep(0.05) # 서버 부하 방지 및 FDR 호출 조절

    df = pd.DataFrame(rows).sort_values('Total_Score', ascending=False)
    print(f'  → {len(df)}개 종목')
    return df


def collect_market_summary(token, df_intraday):
    """시장 요약 데이터 수집 (코스피/코스닥/환율)"""
    print('📉 시장 요약 데이터 수집 중...')
    rows = []

    # FinanceDataReader로 지수 조회
    try:
        # 최근 7일치 데이터를 불러와 마지막 데이터(최신 종가)를 사용
        start_date = (datetime.now(KST) - timedelta(days=7)).strftime('%Y-%m-%d')
        df_ks = fdr.DataReader('KS11', start_date)
        df_kq = fdr.DataReader('KQ11', start_date)
        df_usd = fdr.DataReader('USD/KRW', start_date)

        def last(df, col='Close'):
            if df.empty:
                return 0
            if col in df.columns:
                df_clean = df.dropna(subset=[col])
                if not df_clean.empty:
                    return float(df_clean[col].iloc[-1])
            return 0

        def chg(df):
            if df.empty:
                return 0
            df_clean = df.dropna(subset=['Close'])
            if 'Change' in df_clean.columns:
                val = df_clean['Change'].iloc[-1]
                if pd.notna(val):
                    return float(val * 100)
            if 'Close' in df_clean.columns and len(df_clean) >= 2:
                prev_close = df_clean['Close'].iloc[-2]
                if prev_close != 0 and pd.notna(prev_close):
                    return float((df_clean['Close'].iloc[-1] - prev_close) / prev_close * 100)
            return 0

        def trend(v):
            return '▲' if v > 0 else ('▼' if v < 0 else '-')

        # 수급 데이터 (네이버 실시간 API 1순위 -> intraday 마지막 값 폴백)
        def get_supply(market):
            try:
                headers = {'User-Agent': 'Mozilla/5.0'}
                ep = 'KOSPI' if market == '코스피' else 'KOSDAQ'
                r = requests.get(f'https://m.stock.naver.com/api/index/{ep}/trend', headers=headers, timeout=2.0)
                if r.status_code == 200:
                    d = r.json()
                    fgn = int(str(d.get('foreignValue', '0')).replace(',', '').replace('+', ''))
                    psn = int(str(d.get('personalValue', '0')).replace(',', '').replace('+', ''))
                    org = int(str(d.get('institutionalValue', '0')).replace(',', '').replace('+', ''))
                    if fgn != 0 or psn != 0 or org != 0:
                        return fgn, psn, org
            except Exception as e:
                print(f'DEBUG naver trend fetch error for {market}: {e}')

            if df_intraday.empty or 'Market' not in df_intraday.columns:
                return 0, 0, 0
            df_m = df_intraday[df_intraday['Market'] == market]
            if df_m.empty:
                return 0, 0, 0
            last_row = df_m.sort_values('Time').iloc[-1]
            return (
                int(last_row.get('Foreign_Net', 0)),
                int(last_row.get('Individual_Net', 0)),
                int(last_row.get('Institutional_Net', 0))
            )

        # 네이버 실시간 지수 API 1순위 조회 (FDR 당일 장마감 후 지연/누락 방지)
        naver_indices = {}
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            r_nv = requests.get('https://polling.finance.naver.com/api/realtime/domestic/index/KOSPI,KOSDAQ', headers=headers, timeout=2.5)
            if r_nv.status_code == 200:
                for item in r_nv.json().get('datas', []):
                    k = '코스피' if item.get('itemCode') == 'KOSPI' else '코스닥'
                    p_val = float(str(item.get('closePrice', '')).replace(',', ''))
                    chg_val = float(str(item.get('fluctuationsRatio', '0')).replace(',', ''))
                    naver_indices[k] = {
                        'price': f"{p_val:,.2f}",
                        'chg': chg_val,
                        'chg_str': f"{chg_val:+.2f}%",
                        'trend': '▲' if chg_val > 0 else ('▼' if chg_val < 0 else '-')
                    }
        except Exception as e:
            print(f'DEBUG naver real-time index fetch error: {e}')

        ks_p = naver_indices.get('코스피', {}).get('price', f'{last(df_ks):,.2f}')
        ks_chg = naver_indices.get('코스피', {}).get('chg', chg(df_ks))
        ks_chg_str = naver_indices.get('코스피', {}).get('chg_str', f'{ks_chg:+.2f}%')
        ks_trend = naver_indices.get('코스피', {}).get('trend', trend(ks_chg))

        kq_p = naver_indices.get('코스닥', {}).get('price', f'{last(df_kq):,.2f}')
        kq_chg = naver_indices.get('코스닥', {}).get('chg', chg(df_kq))
        kq_chg_str = naver_indices.get('코스닥', {}).get('chg_str', f'{kq_chg:+.2f}%')
        kq_trend = naver_indices.get('코스닥', {}).get('trend', trend(kq_chg))

        usd_chg = chg(df_usd)

        fgn_ks, ind_ks, inst_ks = get_supply('코스피')
        fgn_kq, ind_kq, inst_kq = get_supply('코스닥')

        rows = [
            {
                '종목/종류': '코스피',
                '지수': ks_p,
                '등락률': ks_chg_str,
                '추이': ks_trend,
                '외국인(억)': str(fgn_ks),
                '개인(억)': str(ind_ks),
                '기관(억)': str(inst_ks),
            },
            {
                '종목/종류': '코스닥',
                '지수': kq_p,
                '등락률': kq_chg_str,
                '추이': kq_trend,
                '외국인(억)': str(fgn_kq),
                '개인(억)': str(ind_kq),
                '기관(억)': str(inst_kq),
            },
            {
                '종목/종류': 'USD/KRW',
                '지수': f'{last(df_usd):,.2f}',
                '등락률': f'{usd_chg:+.2f}%',
                '추이': trend(usd_chg),
                '외국인(억)': '-',
                '개인(억)': '-',
                '기관(억)': '-',
            },
        ]
    except Exception as e:
        print(f'  ❌ 지수 조회 오류: {e}')
        rows = []

    df = pd.DataFrame(rows)
    print(f'  → {len(df)}행')
    return df


def collect_supply_intraday(token):
    """네이버 API: 코스피/코스닥 수급 일중 추이 데이터 수집 (30분 단위 누적)

    [방식]
    - 네이버 m.stock trend API로 현재 시점 수급 스냅샷(억원) 획득
    - 기존 당일 CSV를 로컬 파일에서 불러와 현재 시간 포인트를 append
    - 새 날짜이면 자동으로 초기화 (날짜 컬럼으로 구분)
    - GitHub Actions가 30분마다 실행하므로 하루 최대 13개 포인트(09:00~15:30) 적재
    - 장외 시간(09:00~15:30 KST 외) 데이터는 저장하지 않음
    """
    print('장중 수급 시계열 데이터 수집 중 (네이버 API)...')
    # GitHub Actions는 UTC 환경 → KST(UTC+9)로 변환하여 한국 시장 시간 기준으로 저장
    from datetime import timezone
    now_utc = datetime.now(tz=timezone.utc)
    now = now_utc + timedelta(hours=9)  # UTC → KST 변환
    now_str = now.strftime('%H:%M')
    today_str = now.strftime('%Y%m%d')
    h_m = now.hour * 100 + now.minute

    # 장외 시간이면:
    # 단, 장 마감(15:30) 이후인데 오늘자 15:30 최종 종가 수급 데이터가 아직 수집되지 않았다면,
    # 1회에 한해 네이버에서 최종 마감 수급 스냅샷을 가져와 '15:30'으로 완결짓는다!
    is_after_market = h_m > 1530
    existing_path = os.path.join(DATA_DIR, 'df_supply_intraday.csv')
    df_existing = pd.DataFrame(columns=['Date', 'Time', 'Market', 'Foreign_Net', 'Individual_Net', 'Institutional_Net'])
    
    if os.path.exists(existing_path):
        try:
            _d_loaded = pd.read_csv(existing_path, encoding='utf-8-sig')
            if 'Date' in _d_loaded.columns:
                df_existing = _d_loaded[_d_loaded['Date'].astype(str) == today_str].copy()
        except Exception:
            pass

    # 장 시작 전(09:00 이전)이거나, 이미 15:30 마감 데이터가 들어있는 장 마감 후라면 생략
    has_closing_point = not df_existing.empty and (df_existing['Time'] == '15:30').any()
    if h_m < 900 or (is_after_market and has_closing_point):
        print(f'  ⚠️ 수급 스냅샷 수집 생략 (현재시각: {now_str}, 마감데이터보유: {has_closing_point})')
        return df_existing

    # 장 마감 후 최초 1회 실행인 경우 타임스탬프를 '15:30'으로 고정
    if is_after_market and not has_closing_point:
        print(f'  🌙 장마감(15:30) 최종 수급 스냅샷 누락 감지 → 최종 마감값으로 15:30 완결 기록')
        now_str = '15:30'

    def _parse_naver_supply(val_str):
        """'+5,254' 형태의 네이버 수급 문자열을 억원 정수로 변환"""
        try:
            return int(str(val_str).replace(',', '').replace('+', '').strip())
        except Exception:
            return 0

    # 1. 네이버 API로 현재 수급 스냅샷 획득
    headers = {'User-Agent': 'Mozilla/5.0'}
    new_rows = []
    for mkt_code, mkt_name in [('KOSPI', '코스피'), ('KOSDAQ', '코스닥')]:
        try:
            r = requests.get(
                f'https://m.stock.naver.com/api/index/{mkt_code}/trend',
                headers=headers, timeout=5
            )
            if r.status_code == 200:
                d = r.json()
                # bizdate 확인: 오늘 날짜 데이터인지 검증
                api_date = str(d.get('bizdate', today_str))
                if api_date != today_str:
                    print(f'  {mkt_name} 수급: API 날짜({api_date}) != 오늘({today_str}), 스킵')
                    continue
                new_rows.append({
                    'Date':              today_str,
                    'Time':              now_str,
                    'Market':            mkt_name,
                    'Foreign_Net':       _parse_naver_supply(d.get('foreignValue', '0')),
                    'Individual_Net':    _parse_naver_supply(d.get('personalValue', '0')),
                    'Institutional_Net': _parse_naver_supply(d.get('institutionalValue', '0')),
                })
                print(f'  {mkt_name}: 외국인={d.get("foreignValue")} 개인={d.get("personalValue")} 기관={d.get("institutionalValue")}')
        except Exception as e:
            print(f'  {mkt_name} 네이버 수급 조회 실패: {e}')

    if not new_rows:
        print('  ⚠️ 수급 스냅샷 데이터 없음 → 기존 파일 유지')
        # 기존 파일이 있으면 그대로 반환
        existing_path = os.path.join(DATA_DIR, 'df_supply_intraday.csv')
        if os.path.exists(existing_path):
            try:
                df_existing = pd.read_csv(existing_path, encoding='utf-8-sig')
                # 오늘 날짜 데이터만 유지
                if 'Date' in df_existing.columns:
                    df_existing = df_existing[df_existing['Date'].astype(str) == today_str]
                return df_existing
            except Exception:
                pass
        return pd.DataFrame(columns=['Date', 'Time', 'Market', 'Foreign_Net', 'Individual_Net', 'Institutional_Net'])

    df_new = pd.DataFrame(new_rows)

    # 2. 기존 당일 누적 데이터 로드 (로컬 파일 우선, 없으면 GitHub raw URL)
    df_existing = pd.DataFrame(columns=['Date', 'Time', 'Market', 'Foreign_Net', 'Individual_Net', 'Institutional_Net'])
    local_path = os.path.join(DATA_DIR, 'df_supply_intraday.csv')

    if os.path.exists(local_path):
        try:
            df_loaded = pd.read_csv(local_path, encoding='utf-8-sig')
            # 날짜 컬럼이 없는 구버전 파일이면 초기화
            if 'Date' not in df_loaded.columns:
                print('  ℹ️ 구버전 포맷 감지 → 오늘부터 새로 누적')
            else:
                # 오늘 날짜 데이터만 유지 (전일 데이터 자동 제거)
                df_existing = df_loaded[df_loaded['Date'].astype(str) == today_str].copy()
                print(f'  ✅ 기존 {len(df_existing)}개 포인트 로드 완료')
        except Exception as e:
            print(f'  ⚠️ 기존 파일 로드 실패: {e}')

    # 3. 현재 시간 중복 제거 후 append
    if not df_existing.empty:
        # 이미 같은 시간·같은 시장 데이터가 있으면 덮어쓰기 (중복 방지)
        df_existing = df_existing[
            ~((df_existing['Time'] == now_str) &
              (df_existing['Market'].isin(df_new['Market'].tolist())))
        ]

    df_combined = pd.concat([df_existing, df_new], ignore_index=True)
    
    # ── [시초 0 기준선 보장] 09:00 틱이 누적 데이터에 없다면 자동으로 추가 ──
    for m_name in ['코스피', '코스닥']:
        has_9am = not df_combined.empty and ((df_combined['Market'] == m_name) & (df_combined['Time'] == '09:00')).any()
        if not has_9am:
            seed_row = pd.DataFrame([{
                'Date': today_str, 'Time': '09:00', 'Market': m_name,
                'Foreign_Net': 0, 'Individual_Net': 0, 'Institutional_Net': 0
            }])
            df_combined = pd.concat([seed_row, df_combined], ignore_index=True)

    # 시간 순 정렬
    df_combined = df_combined.drop_duplicates(subset=['Date', 'Time', 'Market'], keep='last').sort_values(['Market', 'Time']).reset_index(drop=True)

    # 4. Supabase DB에 실시간 스냅샷 upsert
    if supabase and not df_new.empty:
        try:
            print("  ⚡ Supabase DB에 실시간 수급 스냅샷 적재 중...")
            for _, row in df_new.iterrows():
                supabase.table("supply_intraday").upsert({
                    "date": str(row['Date']),
                    "time": str(row['Time']),
                    "market": str(row['Market']),
                    "foreign_net": int(row['Foreign_Net']),
                    "individual_net": int(row['Individual_Net']),
                    "institutional_net": int(row['Institutional_Net'])
                }).execute()
            print("  ✅ Supabase DB 적재 성공")
        except Exception as db_err:
            print(f"  ❌ Supabase upsert 실패: {db_err}")

    print(f'  → 총 {len(df_combined)}개 포인트 (오늘 {today_str})')
    return df_combined


# ── 메인 실행 ────────────────────────────────────────────────────
def main():
    print('=' * 50)
    print(f'🚀 GD 3.0 데이터 수집 시작: {datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")} KST')
    print('=' * 50)

    if not APP_KEY or not APP_SECRET:
        print('⚠️ KIS_APP_KEY / KIS_APP_SECRET 환경변수가 설정되지 않았습니다. (일부 수급 데이터가 누락됩니다.)')
        # sys.exit(1) 대신 KIS 토큰 없이 실행을 계속함

    # KIS 토큰 발급
    print('\n🔑 KIS API 토큰 발급 중...')
    token = get_access_token() if APP_KEY and APP_SECRET else None
    if not token and (APP_KEY and APP_SECRET):
        print('❌ 토큰 발급 실패')
        return
    elif not token:
        print('  ⚠️ KIS 토큰 발급 건너뜀 (인증키 없음)')
    else:
        print('  ✅ 토큰 발급 완료')

    print('데이터 수집 시작...')
    # 한국 표준시(KST)로 정확한 장중/장외 판단
    now_kst = datetime.now(KST)
    kst_h_m = now_kst.hour * 100 + now_kst.minute
    print(f'현재 KST: {now_kst.strftime("%Y-%m-%d %H:%M")} ({"장중" if 900 <= kst_h_m <= 1530 else "장외"})')

    df_full     = collect_full_market()
    df_intraday = collect_supply_intraday(token)
    df_hd       = collect_high_density(token, df_full)
    df_quant    = collect_quant_final(token, df_hd, df_full)
    df_summary  = collect_market_summary(token, df_intraday)

    # 로컬 data/ 폴더에 CSV 저장 (GitHub Actions가 커밋·푸시)
    print('\n💾 data/ 폴더에 CSV 저장 중...')
    saves = [
        (df_full,     'df_full_market.csv'),
        (df_intraday, 'df_supply_intraday.csv'),
        (df_hd,       'df_high_density.csv'),
        (df_quant,    'df_quant_final.csv'),
        (df_summary,  'df_market_summary.csv'),
    ]

    for df, fname in saves:
        if df.empty:
            print(f'  ⚠️ {fname}: 데이터 없음, 건너뜀')
            continue
        try:
            save_df_to_local(df, fname)
        except Exception as e:
            print(f'  ❌ {fname} 저장 실패: {e}')

    print('\n' + '=' * 50)
    print(f'✅ 수집 완료: {datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")} KST')
    print('=' * 50)


if __name__ == '__main__':
    main()
